import os
import json
from dotenv import load_dotenv
import openai
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

def analyze_feedback(startup_id: str, feedback_entries: list) -> dict:
    # Calculate average score
    scores = [entry['score'] for entry in feedback_entries if isinstance(entry.get('score'), (int, float))]
    avg_score = sum(scores) / len(scores) if scores else None

    # Extract comments for theme clustering
    comments = [entry['comment'] for entry in feedback_entries if entry.get('comment')]
    vectorizer = TfidfVectorizer(stop_words='english')
    X = vectorizer.fit_transform(comments)
    n_clusters = min(5, len(comments))
    kmeans = KMeans(n_clusters=n_clusters, random_state=42).fit(X)
    clusters = {i: [] for i in range(n_clusters)}
    for idx, label in enumerate(kmeans.labels_):
        clusters[label].append(comments[idx])

    top_themes = ['; '.join(v[:2]) for v in clusters.values()]

    # Use LLM to summarize insights
    prompt = (
        f"Startup ID: {startup_id}\n"
        f"Average Score: {avg_score}\n"
        f"Themes: {top_themes}\n"
        f"Feedback Entries: {json.dumps(feedback_entries, indent=2)}\n"
        "Generate a JSON with keys: average_score, top_themes, positive_insights, critical_feedback, summary."
    )
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
        )
    try:
        return json.loads(response.choices[0].message.content)
    except Exception:
        return {"error": "Failed to parse model output", "raw": response.choices[0].message.content}
