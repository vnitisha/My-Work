import os
import json
from dotenv import load_dotenv
from google import genai
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
import re


load_dotenv()

client = genai.Client(api_key=os.getenv("AIzaSyDFqPk-r4770aYuoPKS_XpABoCT8728G4o"))

def analyze_feedback(startup_id: str, feedback_entries: list) -> dict:
    # Calculate average score
    scores = [entry['score'] for entry in feedback_entries if isinstance(entry.get('score'), (int, float))]
    avg_score = sum(scores) / len(scores) if scores else None

    # Extract comments for theme clustering
    comments = [entry['comment'] for entry in feedback_entries if entry.get('comment')]
    vectorizer = TfidfVectorizer(stop_words='english')
    X = vectorizer.fit_transform(comments)
    n_clusters = min(5, len(comments))
    kmeans = KMeans(n_clusters=n_clusters, random_state=42).fit(X)
    clusters = {i: [] for i in range(n_clusters)}
    for idx, label in enumerate(kmeans.labels_):
        clusters[label].append(comments[idx])

    top_themes = ['; '.join(v[:2]) for v in clusters.values()]

    # Use LLM to summarize insights
    prompt = (
        f"Startup ID: {startup_id}\n"
        f"Average Score: {avg_score}\n"
        f"Themes: {top_themes}\n"
        f"Feedback Entries: {json.dumps(feedback_entries, indent=2)}\n"
        "Generate a JSON with keys: average_score, top_themes, positive_insights, critical_feedback, summary."
    )
    # start a chat session with Gemini
    chat = client.chats.create(model="gemini-2.0-flash-001")
    ai_reply = chat.send_message(prompt)
    raw_text = ai_reply.text

    # 1) strip any ```json or ``` fences
    cleaned = re.sub(r"```(?:json)?\s*", "", raw_text).replace("```", "").strip()
    # 2) grab first { … } block
    m = re.search(r"(\{.*\})", cleaned, re.S)
    if m:
        cleaned = m.group(1)
    # 3) parse
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        return {"error": "Failed to parse model output", "raw": raw_text}