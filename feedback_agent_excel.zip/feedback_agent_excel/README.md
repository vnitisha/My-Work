# Feedback Agent

This agent processes structured feedback entries and generates actionable insights.

## Setup

1. Clone the repository or unzip the package.
2. Create a virtual environment and install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Populate the `.env` file with your OpenAI API key:
   ```bash
    GEMINI_API_KEY=ya29.AIzaSyDFqPk-r4770aYuoPKS_XpABoCT8728G4o
   ```

## Usage

```bash
python agent.py --input feedback.json --output summary.json
```

- `feedback.json` should contain:
  ```json
  {
    "startup_id": "your_startup_id",
    "feedback_entries": [
      {
        "reviewer_role": "mentor",
        "score": 7,
        "comment": "Needs better differentiation",
        "suggested_feature": "Highlight USP earlier"
      },
      ...
    ]
  }
  ```
- `summary.json` will contain the structured insights:
  ```json
  {
    "average_score": 6.8,
    "top_themes": [...],
    "positive_insights": [...],
    "critical_feedback": [...],
    "summary": "..."
  }
  ```
