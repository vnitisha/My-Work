import streamlit as st
import pandas as pd
import json
from feedback_processor import analyze_feedback

st.set_page_config(page_title="Feedback Agent", layout="centered")
st.title("Feedback Agent Frontend")

st.markdown("Upload an Excel (.xlsx) file containing your feedback entries to generate insights.")

uploaded_file = st.file_uploader("Choose feedback Excel file", type=["xlsx"])

if uploaded_file:
    try:
        df = pd.read_excel(uploaded_file)
        # Expecting columns: reviewer_role, score, comment, suggested_feature
        feedback_entries = df.to_dict(orient="records")
        startup_id = "Uploaded Excel"

        with st.spinner("Analyzing feedback..."):
            result = analyze_feedback(startup_id, feedback_entries)

        if "error" in result:
            st.error("Error from agent: " + result.get("error"))
            st.write(result.get("raw", ""))
        else:
            st.subheader(f"Insights for {startup_id}")
            st.metric("Average Score", result.get("average_score", "N/A"))

            st.markdown("**Top Themes:**")
            for theme in result.get("top_themes", []):
                st.write(f"- {theme}")

            st.markdown("**Positive Insights:**")
            for pi in result.get("positive_insights", []):
                st.write(f"- {pi}")

            st.markdown("**Critical Feedback:**")
            for cf in result.get("critical_feedback", []):
                st.write(f"- {cf}")

            st.markdown("**Summary:**")
            st.write(result.get("summary", ""))

    except Exception as e:
        st.error(f"Failed to process file: {e}")
else:
    st.info("Awaiting Excel file upload...")
