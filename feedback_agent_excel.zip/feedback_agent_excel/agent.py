import json
import click
from feedback_processor import analyze_feedback

@click.command()
@click.option('--input', 'input_path', required=True, help='Path to input JSON file')
@click.option('--output', 'output_path', required=True, help='Path to output JSON file')
def main(input_path, output_path):
    with open(input_path, 'r') as f:
        data = json.load(f)
    summary = analyze_feedback(data.get('startup_id'), data.get('feedback_entries', []))
    with open(output_path, 'w') as f:
        json.dump(summary, f, indent=2)
    print(f"Summary written to {output_path}")

if __name__ == '__main__':
    main()
